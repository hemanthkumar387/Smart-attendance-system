import cv2
import numpy as np
import face_recognition
# from PIL import ImageGrab


imgBhanu = face_recognition.load_image_file('C:\\Users\\vishn\OneDrive\\Desktop\\Hackthon2\\FaceRecognitionalAttendence\\Images\\Bhanu Prabhas.jpeg')
imgBhanu = cv2.cvtColor(imgBhanu, cv2.COLOR_BGR2RGB)
imgHemanth = face_recognition.load_image_file('C:\\Users\\vishn\\OneDrive\\Desktop\\Hackthon2\\FaceRecognitionalAttendence\\Images\\Hemanth Kumar.jpeg')
imgHemanth = cv2.cvtColor(imgHemanth, cv2.COLOR_BGR2RGB)

faceLoc = face_recognition.face_locations(imgBhanu)[0]
encodeBhanu = face_recognition.face_encodings(imgBhanu)[0]
cv2.rectangle(imgBhanu, (faceLoc[3], faceLoc[0]),(faceLoc[1], faceLoc[2]), (255, 0, 255), 2 )

faceLocTest = face_recognition.face_locations(imgHemanth)[0]
encodeHemanth = face_recognition.face_encodings(imgHemanth)[0]
cv2.rectangle(imgHemanth, (faceLocTest[3], faceLocTest[0]), (faceLocTest[1], faceLocTest[2]), (255, 0, 255), 2)

results = face_recognition.compare_faces([encodeBhanu], encodeHemanth)
faceDis = face_recognition.face_distance([encodeBhanu], encodeHemanth)
print(results, faceDis)
cv2.putText(imgHemanth, f'{results} {round(faceDis[0], 2)}', (50, 50), cv2.FONT_HERSHEY_COMPLEX, 1, (0, 0, 255), 2)

cv2.imshow('Bhanu Prabhas', imgBhanu)
cv2.imshow('Hemanth Kumar', imgHemanth)
cv2.waitKey(0)